/* COMP2215 15/16 Task 7---Keyboard */

#include "os.h"

int show_keyboard(int);
//char* append(char*, char*);

typedef enum { false, true } bool;

int length = 0;
int line = 0;
int letter = 0;
bool keyboard = false;
int mode = 0;
//char* output;
 

void main(void) {
    os_init();

    os_add_task( show_keyboard,    30, 1);
     
    sei();
    for(;;){}  
}

// Unsure how to get asprintf to work so cannot use
/*char* append(char* string1, char* string2){
	char* result = NULL;
	asprintf(&result, "%s%s", string1, string2);
	return result;
}*/

int show_keyboard (int state) {
	if (get_switch_press(_BV(SWN))){
		// Change whether keyboard is showing
		if (mode == 2 || mode == 0){
			keyboard = !keyboard;
		}
		
		mode = (mode + 1) % 3;	
	
		// Hide keyboard
		rectangle clear_keyboard = {0,display.width-1, 0, 14};
		fill_rectangle(clear_keyboard,display.background);
		
		if (keyboard){
			// Display keyboard
			if (mode == 1) {
        			display_string_xy(" a b c d e f g h i j k l m n o p q r s t u v w x y z\n\n",0,0);
			}
			if (mode == 2){
				display_string_xy(" A B C D E F G H I J K L M N O P Q R S T U V W X Y Z\n\n",0,0);
			}
		}

	}
	if (keyboard){
		// Move cursor
        	rectangle left = {0, (letter*12+6), 8,14};
		rectangle right = {(letter*12+11),display.width-1, 8, 14};
		fill_rectangle(left,display.background);
		fill_rectangle(right,display.background);
        	rectangle r = {(letter*12+6), (letter*12 + 11), 8, 14};
		fill_rectangle(r, RED);
        	
		//SPACE When you press right
		if (get_switch_press(_BV(SWE))){
			char c = 32;
			//output = append(output, c);
			display_char(c);
			length++;
		}

		// Backspace on right
        	if (get_switch_press(_BV(SWW))){
			rectangle backspace = {(length*12),(length*12 + 5),14,6};
			fill_rectangle(backspace,display.background);
		}

		// New line on down
		if (get_switch_press(_BV(SWS))){
			// NEW LINE CHARACTER
			display_string("\n");
			length = 0;
			line ++;
		}
		

		// SCROLL WHEEL
		letter += os_enc_delta();
		if(letter > 25){
			letter = 25;
		}
		if (letter < 0){
			letter = 0;
		}

		if (get_switch_long(_BV(SWC))) {
			char c;
			if (mode == 2){
				c = 65 + letter;
			}else{
				c = 97 + letter;
			}
			//output = append(output, c);
			display_char(c);
			length++;
		}
	}
}

