#include "os.h"

#define MAX_OUTPUT 55
#define INIT_MODE 1

typedef enum { false, true } bool;

char *read_keyboard(char*);
int show_keyboard(int);
